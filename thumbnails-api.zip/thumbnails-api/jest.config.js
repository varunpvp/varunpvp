/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  preset: "ts-jest",
  testEnvironment: "node",
  clearMocks: true,

  roots: [
    "<rootDir>/packages/api",
    "<rootDir>/packages/worker",
    "<rootDir>/e2e",
  ],

  testMatch: ["**/*.test.ts"],

  testTimeout: 10000,

  detectOpenHandles: true,
  forceExit: true,
};
