# Thumbnail API Service

**Author:** Varun Pujari (varunpvp@gmail.com)

This project implements a backend API service for uploading images and asynchronously generating 100x100 WebP thumbnails using a background worker queue.

---

## Table of Contents

- [How to Run (Simplified Docker Method)](#how-to-run-simplified-docker-method)
- [Features](#features)
- [API Endpoints](#api-endpoints)
- [Tech Stack](#tech-stack)
- [Architecture & Design Choices](#architecture--design-choices)
- [Trade-offs & Future Improvements](#trade-offs--future-improvements)
- [Alternative Setup: Local Development](#alternative-setup-local-development)
- [Project Structure](#project-structure)
- [Running Tests](#running-tests)
- [Code Quality & Formatting](#code-quality--formatting)

---

## How to Run (Simplified Docker Method)

This project uses Docker Compose and is configured for a quick start using default settings.

1.  **Prerequisites:**

    - Ensure Docker & Docker Compose are installed and running.
    - Extract the code from the provided `.zip` file into a directory.

2.  **Configuring `.env.example` (Optional):**

    - Navigate into the root directory of the extracted code in your terminal.
    - This project uses the **`.env.example`** file for its default settings needed to run the application, covering database (Postgres), queue (Redis), storage (MinIO), API, and Worker configurations. Comments within the `.env.example` file explain each variable.
    - For easy startup, `docker-compose up` is configured to use this file directly, loading defaults for ports, local service credentials, etc.
    - You can examine `.env.example` before running to see the default configuration.

3.  **Launch the Application:**

    - Run the following command from the root directory:
      ```bash
      docker-compose up
      ```
    - **What happens:**
      - Docker Compose reads `docker-compose.yml` and loads configuration from `.env.example`.
      - It builds the necessary Docker images for `api` and `worker` (including installing dependencies). This may take time initially.
      - It starts all services (database, redis, minio, api, worker).
      - It automatically handles database schema migrations.

4.  **Access Services:**

    - Once startup completes, the API service will run on `http://localhost:3030` by default.

## Features

- **Image Upload:** Submit images via a REST API endpoint.
- **Asynchronous Thumbnail Generation:** Generates 100x100 **WebP** thumbnails in the background using a job queue.
- **Job Status Tracking:** Check the status (`PENDING`, `PROCESSING`, `SUCCEEDED`, `FAILED`) of submitted jobs using a **UUID**.
- **Thumbnail Retrieval:** Fetch generated **WebP** thumbnails via an API endpoint once processing is successful.
- **Job Listing:** List all submitted jobs, with support for **pagination** using `page` and `pageSize`.
- **Automatic Cleanup:** Deletes the original uploaded file from storage after successful thumbnail generation.

## API Endpoints

The API service runs on `http://localhost:3030` by default.

- **`POST /api/v1/jobs`**

  - **Description:** Submits an image to generate a thumbnail.
  - **Request:** `multipart/form-data` with a single file field named `image`.
  - **Headers:** `Content-Type: multipart/form-data`
  - **Success Response (202 Accepted):** Returns job details with `PENDING` status.
    ```json
    {
      "status": "success",
      "data": {
        "id": "a1b2c3d4-e5f6-7890-1234-567890abcdef", // UUID format
        "status": "PENDING",
        "savedFileName": "unique-name-in-minio.jpg", // Represents the stored original file
        "createdAt": "...",
        "updatedAt": "...",
        "errorMessage": null
      }
    }
    ```
  - **Error Responses:** `400 Bad Request` (Unsupported file type or file size to large), `404 Not Found` (No image file provided).
  - **Example using `curl`:**
    ```bash
    curl -X POST -F "image=@/path/to/your/image.jpg" http://localhost:3030/api/v1/jobs
    ```

- **`GET /api/v1/jobs/:jobId`**

  - **Description:** Checks the status of a specific job.
  - **URL Params:** `jobId` (string, UUID format)
  - **Success Response (200 OK):** Returns job details.
    ```json
    {
      "status": "success",
      "data": {
        "id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
        "status": "PROCESSING", // or PENDING, SUCCEEDED, FAILED
        "savedFileName": "...",
        "createdAt": "...",
        "updatedAt": "...",
        "errorMessage": null // Contains error message if status is FAILED
      }
    }
    ```
  - **Error Responses:** `400 Bad Request` (Invalid Job ID format.), `404 Not Found` (Job with ID ${jobId} not found.).
  - **Example using `curl`:**
    ```bash
    curl http://localhost:3030/api/v1/jobs/a1b2c3d4-e5f6-7890-1234-567890abcdef
    ```

- **`GET /api/v1/jobs`**

  - **Description:** Lists all submitted jobs (most recent first). Supports pagination.
  - **Query Parameters (Optional):**
    - `page` (number): Page number (default: 1).
    - `pageSize` (number): Items per page (default: 10).
  - **Success Response (200 OK):** Returns a list of jobs and pagination metadata.
    ```json
    {
      "status": "success",
      "data": [
        {
          "id": "...",
          "status": "..." // ... job fields
        }
        // ... other jobs on the current page
      ],
      "meta": {
        "total": 123,
        "page": 1,
        "pageSize": 10,
        "totalPages": 1
      }
    }
    ```
  - **Error Responses:** `400 Bad Request` (Invalid query parameters.).
  - **Example using `curl`:**
    ```bash
    # Get page 2 with 5 items per page
    curl "http://localhost:3030/api/v1/jobs?page=2&pageSize=5"
    ```

- **`GET /api/v1/thumbnails/:jobId`**
  - **Description:** Retrieves the generated thumbnail image. Only works if the job status is `SUCCEEDED`.
  - **URL Params:** `jobId` (string, UUID format)
  - **Success Response (200 OK):** Returns the image data directly.
  - **Headers:** `Content-Type: image/webp`
  - **Error Responses:** `400 Bad Request` (Invalid Job ID format.), `404 Not Found` (Thumbnail for job ID ${jobId} not found or not ready.).
  - **Example using `curl` (save to file):**
    ```bash
    curl -o thumbnail.webp http://localhost:3030/api/v1/thumbnails/a1b2c3d4-e5f6-7890-1234-567890abcdef
    ```
  - **Example (view in browser):** Navigate to `http://localhost:3030/api/v1/thumbnails/a1b2c3d4-e5f6-7890-1234-567890abcdef`

## Tech Stack

- **Language:** TypeScript
- **Framework:** Node.js with Express.js (API)
- **Database:** PostgreSQL
- **ORM:** Prisma
- **Job Queue:** BullMQ using Redis
- **Image Processing:** Sharp
- **Storage:** MinIO (S3-compatible object storage)
- **Containerization:** Docker & Docker Compose
- **Package Manager:** npm (using workspaces)

## Architecture & Design Choices

```mermaid
flowchart TD
  User[Client]
  API[API]
  Worker[Worker]
  Queue[Queue]
  DB[(Database)]
  Storage[Storage]

  User-->|Upload|API
  API-->|Store|Storage
  API-->|Queue Job|Queue
  Queue-->|Process|Worker
  Worker-->|Read|Storage
  Worker-->|Write|Storage
  Worker-->|Update|DB
  User-->|Check Status|API
  API-->|Get Status|DB
  User-->|Download|API
  API-->|Fetch|Storage
```

- **Monorepo:** Uses npm workspaces to manage the `api` and `worker` packages, simplifying dependencies and code sharing.
- **API Service (Express):** Handles HTTP requests, validation, interacts with the database, and enqueues jobs. Uses Multer for file uploads.
- **Worker Service (Redis + BullMQ):** A separate process listens to the Redis-backed queue for jobs, handling the decoupled, time-consuming image processing.
- **Database (PostgreSQL + Prisma):** PostgreSQL provides reliable relational storage, fitting well with common tech stacks including Node.js. Prisma was chosen as the ORM primarily for its excellent TypeScript integration, which provides end-to-end type safety for database queries. Furthermore, Prisma includes a robust migration system that significantly simplifies generating, applying, and versioning database schema changes, ensuring consistency across different environments. This makes database interactions safer and more maintainable.
- **Image Processing (Sharp):** A high-performance library used for resizing images and generating **WebP** thumbnails.
- **Storage (MinIO):** Leverages MinIO, an **AWS S3 compatible object storage**, for scalable image persistence. The API uploads originals to MinIO; the worker processes them and uploads thumbnails back, deleting the original upon success.
- **Containerization (Docker):** Docker and Docker Compose define, build, and run the application services consistently. Separate files like `docker-compose.dev.yml` and `docker-compose.test.yml` are provided for specific environment setup

## Trade-offs & Future Improvements

- **Storage:**
  - **Current:** Uses self-hosted MinIO, providing scalable S3-compatible storage.
  - **Future:** Consider using a managed cloud object storage service (AWS S3, GCS, etc.) for enhanced durability, availability, and reduced operational overhead in production.
- **Error Handling:** Basic error handling is implemented. Production systems would benefit from robust error tracking/reporting (e.g., Sentry), dead-letter queues for failed jobs, and potentially more specific API error responses.
- **Scalability:**
  - **Current:** Workers scale horizontally (`docker-compose --scale worker=N`) and vertically (adjusting `WORKER_CONCURRENCY`). MinIO offers scalable storage; Redis/Postgres are potential bottlenecks.
  - **Future:** To enhance scalability and reliability, the API can scale (multiple instances + load balancer). We can use Kubernetes for orchestration and updates, implementing database connection pooling (and read replicas, if necessary), and migrating to managed cloud services for Postgres and Redis to simplify operations.
- **Performance Testing:** To ensure the API handles traffic effectively and reliably, performance testing can be implemented. This should include different strategies based on expected traffic patterns:
  - **Load Testing:** Simulating expected user load to measure baseline performance and identify bottlenecks under normal conditions.
  - **Stress Testing:** Pushing the system beyond normal limits to find its breaking point and maximum capacity.
  - **Soak Testing:** Applying moderate load over an extended period to check for issues like memory leaks or performance degradation over time.
  - **Spike Testing:** Simulating sudden, sharp increases in traffic to evaluate how the system responds to and recovers from bursts.
    Results from these tests would provide confidence in the system's stability and guide further scaling optimizations.
- **Automation (CI/CD):** Setting up a Continuous Integration and Continuous Deployment (CI/CD) pipeline (using tools like GitHub Actions) would significantly improve the development and release process. This pipeline should automate building Docker images, **execute the full test suite (unit, integration, E2E) automatically** on commits or pull requests to catch regressions early, and handle **automated deployments** to staging and production environments, ensuring faster feedback and more reliable, consistent releases.
- **CDN for Faster Thumbnail Delivery:** To significantly accelerate thumbnail loading times for end-users, especially globally, generated thumbnails could be stored in a AWS S3 bucket. Placing a Content Delivery Network (CDN) like AWS CloudFront in front of this bucket would cache thumbnail images at edge locations closer to users, drastically reducing latency and improving perceived performance.
- **Testing:** End-to-end, integration, and unit tests are included to cover the main application flow and component logic. While core functionality is verified, adding more tests, especially for edge cases and failure scenarios, would improve overall coverage.
- **Security:**
  - Authentication/authorization is not implemented as per requirements.
  - Input validation (file type/size) is basic; could be enhanced.
  - API rate limiting should be added.
  - **Secrets Management:** Using committed files like `.env.example` (even if loaded via `env_file` in `docker-compose.yml`) for configuration containing potential defaults is **not safe for production secrets**. Implement secure secrets management using cloud provider services (like AWS Secrets Manager, GCP Secret Manager) for production environments.
- **Monitoring & Logging:** Basic console logging is present. Production requires logging sent to a central platform (ELK, Datadog, etc.) and application metrics (queue stats, processing times, error rates) exposed for monitoring and alerting (e.g., via Prometheus/Grafana).
- **Image Cleanup:** The original image is automatically deleted from MinIO after successful thumbnail generation. Logic could be added to clean up artifacts from failed jobs or very old entries.
- **Thumbnail Format/Options:** Currently creates a fixed-size `100x100` **WebP** thumbnail. Could be enhanced to allow API users to specify size, format (JPEG, PNG), quality, etc.

## Alternative Setup: Local Development

This method runs the backing services (DB, Redis, MinIO) in Docker but runs the API and Worker code directly on your local machine using Node.js, which is useful for faster development iterations and debugging.

1.  **Prerequisites:**

    - Node.js (v18 or higher recommended)
    - npm (v7 or higher recommended for workspace support)
    - Docker & Docker Compose

2.  **Start Backing Services:**

    - Configure `.env.dev` file if necessary.
    - Run the following command to start only the database, Redis, and MinIO using the development compose file:
      ```bash
      docker-compose -f docker-compose.dev.yml up -d
      ```

3.  **Install Dependencies:**

    - Install Node.js dependencies from the project root:
      ```bash
      npm install
      ```

4.  **Database Migration:**

    - Apply database schema migrations (connects to the DB running in Docker):
      ```bash
      npx dotenv -e .env.dev -- npm run prisma:migrate:deploy
      # Or for iterative development: npm run prisma:migrate:dev
      ```

5.  **Start Development Servers:**
    - Run the API and Worker concurrently:
      ```bash
      npm run dev
      ```
    - This command starts the API on `http://localhost:3030` and the worker process.

## Project Structure

```
thumbnails-api/
├── packages/
│   ├── api/                # API service
│   │   ├── src/
│   │   │   ├── features/   # Feature modules
│   │   │   ├── config/     # Configurations
│   │   │   └── utils/      # Shared utilities
│   │   └── Dockerfile
│   └── worker/             # Background worker
│       ├── src/
│       │   ├── jobs/       # Job processors
│       │   ├── config/     # Configurations
│       │   └── utils/      # Shared utilities
│       └── Dockerfile
├── prisma/                 # Contains Prisma schema (schema.prisma) & migrations
├── e2e/                    # End-to-end tests
├── docker-compose.yml
├── docker-compose.dev.yml  # Compose file for dev services
├── docker-compose.test.yml # Compose file for testing environment
├── .env.example            # Example environment variables
├── .env.dev                # Environment variables for local development setup
├── .env.test               # Environment variables for testing
└── package.json
```

## Running Tests

Tests are located in the following directories:

- End-to-end tests: `/e2e`
- API package tests: within `packages/api/`
- Worker package tests: within `packages/worker/`

Before running tests, please review the configuration variables provided in `.env.test` to ensure they are appropriate for your environment.

You can run test suites using the following npm scripts from the project's root directory:

- **Run End-to-End Tests:**

  ```bash
  npm run test:e2e
  ```

- **Run API Tests:**

  ```bash
  npm run test:api
  ```

- **Run Worker Tests:**

  ```bash
  npm run test:worker
  ```

## Code Quality & Formatting

This project uses ESLint for identifying potential code issues and Prettier for enforcing consistent code formatting. Basic configurations are included. You can run these checks using the following npm scripts from the project's root directory:

- **Check for Lint Issues:** Runs ESLint on all TypeScript (`.ts`) files in the project.
  ```bash
  npm run lint
  ```
- **Attempt to Automatically Fix Lint Issues:** Runs ESLint in fix mode on TypeScript files.
  ```bash
  npm run lint:fix
  ```
- **Apply Code Formatting:** Runs Prettier to automatically format TypeScript, JavaScript, JSON, and Markdown files.
  ```bash
  npm run format
  ```

**Further Improvement:**

The developer experience and code consistency can be further improved by integrating **Husky** and **lint-staged**. This combination allows for setting up Git hooks (like pre-commit) that automatically run linters and formatters on staged files before they are committed, helping to maintain code standards effortlessly within the team.
