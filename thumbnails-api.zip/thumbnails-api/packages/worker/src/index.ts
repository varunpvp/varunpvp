import { logger } from "./config/logger";
import { shutdownDb } from "./config/db";
import { shutdownWorker } from "./config/queue";

let isShuttingDown = false;

const gracefulShutdown = async (signal: string) => {
  if (isShuttingDown) {
    logger.info("Graceful shutdown already in progress. Ignoring signal.");
    return;
  }

  isShuttingDown = true;

  logger.info(`Received ${signal}. Starting graceful shutdown (worker)...`);

  // stop the worker from accepting new jobs and wait for active jobs
  try {
    await shutdownWorker();
  } catch (error) {
    logger.error(error, "Error closing BullMQ Worker");
  }

  // close database connections
  try {
    await shutdownDb();
  } catch (error) {
    logger.error(error, "Error disconnecting Prisma (worker)");
  }

  logger.info("Graceful shutdown complete (worker).");

  process.exit(0);
};

// listen for termination signals
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));

process.on("unhandledRejection", (reason) => {
  logger.error(reason, "Unhandled Rejection (worker)");
});

process.on("uncaughtException", (error) => {
  logger.error(error, "Uncaught Exception (worker)");
});
