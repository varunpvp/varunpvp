import { Readable } from "node:stream";
import { ReadableStream } from "node:stream/web";
import { type StreamingBlobPayloadOutputTypes } from "@smithy/types";
import {
  GetObjectCommand,
  PutObjectCommand,
  DeleteObjectCommand,
  S3Client,
} from "@aws-sdk/client-s3";
import { mockClient } from "aws-sdk-client-mock";
import { JobStatus } from "@prisma/client";

// setup mocks
const s3Mock = mockClient(S3Client);

const dbMock = {
  job: {
    update: jest.fn().mockResolvedValue({ id: "test-job-id" }),
  },
};

const generateThumbnailMock = jest.fn();

const libStorageUploadDoneMock = jest.fn();

// mock the modules used by processThumbnailJob
jest.mock("../../utils/image", () => ({
  generateThumbnail: generateThumbnailMock,
}));

jest.mock("../../config/db", () => ({
  db: dbMock,
}));

jest.mock("../../config/storage", () => ({
  s3Client: s3Mock,
}));

jest.mock("@aws-sdk/lib-storage", () => ({
  Upload: jest.fn().mockImplementation(() => ({
    done: libStorageUploadDoneMock,
  })),
}));

// import modules after mocks to ensure Jest's module mocking works correctly
import { Upload } from "@aws-sdk/lib-storage";
import { jobsProcessor } from "../jobs.processor";
import { config } from "../../config";

describe("Thumbnail Job Processor", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    s3Mock.reset();
  });

  describe("Happy Path", () => {
    it("should successfully process a thumbnail job", async () => {
      const jobId = "test-job-id";
      const savedFileName = "test-image.jpg";
      const mockImageBuffer = Buffer.from("fake-image-data");
      const mockThumbnailStream = Readable.from(
        Buffer.from("fake-thumbnail-data")
      );

      // Create a Web ReadableStream
      const mockWebStream = new ReadableStream({
        start(controller) {
          controller.enqueue(mockImageBuffer);
          controller.close();
        },
      });

      // mock S3 command responses
      s3Mock.on(GetObjectCommand).resolves({
        Body: {
          transformToWebStream: () => mockWebStream,
        } as unknown as StreamingBlobPayloadOutputTypes,
      });
      s3Mock.on(PutObjectCommand).resolves({});
      s3Mock.on(DeleteObjectCommand).resolves({});

      // mock thumbnail generation
      generateThumbnailMock.mockReturnValue(mockThumbnailStream);

      await jobsProcessor.processThumbnailJob({ jobId, savedFileName });

      // verify DB updates
      expect(dbMock.job.update).toHaveBeenCalledTimes(2);
      expect(dbMock.job.update).toHaveBeenNthCalledWith(1, {
        where: { id: jobId },
        data: { status: JobStatus.PROCESSING },
      });
      expect(dbMock.job.update).toHaveBeenNthCalledWith(2, {
        where: { id: jobId },
        data: {
          status: JobStatus.SUCCEEDED,
          errorMessage: null,
        },
      });

      // verify S3 operations
      expect(s3Mock.calls()).toHaveLength(2);
      expect(s3Mock.call(0).args[0].input).toEqual({
        Bucket: config.storage.bucketName,
        Key: savedFileName,
      });

      expect(Upload).toHaveBeenCalledTimes(1);

      expect(Upload).toHaveBeenCalledWith({
        client: s3Mock,
        params: {
          Bucket: config.storage.bucketName,
          Key: jobId,
          ContentType: "image/webp",
          Body: mockThumbnailStream,
        },
      });

      expect(libStorageUploadDoneMock).toHaveBeenCalledTimes(1);
    });
  });

  describe("Error Handling", () => {
    it("should handle S3 GetObject failures", async () => {
      const jobId = "test-job-id";
      const savedFileName = "test-image.jpg";

      s3Mock.on(GetObjectCommand).rejects(new Error("S3 Get Error"));

      await expect(
        jobsProcessor.processThumbnailJob({ jobId, savedFileName })
      ).rejects.toThrow("S3 Get Error");

      expect(dbMock.job.update).toHaveBeenLastCalledWith({
        where: { id: jobId },
        data: {
          status: JobStatus.FAILED,
          errorMessage: "S3 Get Error",
        },
      });
    });

    it("should handle missing S3 response body", async () => {
      const jobId = "test-job-id";
      const savedFileName = "test-image.jpg";

      s3Mock.on(GetObjectCommand).resolves({ Body: undefined });

      await expect(
        jobsProcessor.processThumbnailJob({ jobId, savedFileName })
      ).rejects.toThrow("No response body from S3");

      expect(dbMock.job.update).toHaveBeenLastCalledWith({
        where: { id: jobId },
        data: {
          status: JobStatus.FAILED,
          errorMessage: "No response body from S3",
        },
      });
    });
  });
});
