import { Readable } from "node:stream";
import { GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { Upload } from "@aws-sdk/lib-storage";
import { JobStatus } from "@prisma/client";
import { db } from "../config/db";
import { s3Client } from "../config/storage";
import { generateThumbnail } from "../utils/image";
import { config } from "../config";
import { logger } from "../config/logger";

interface ThumbnailJobData {
  jobId: string;
  savedFileName: string;
}

const processThumbnailJob = async (data: ThumbnailJobData) => {
  const { jobId, savedFileName } = data;

  logger.info(
    `[Job ${jobId}] Worker picked up job. Processing file: ${savedFileName}`
  );

  try {
    await db.job.update({
      where: { id: jobId },
      data: { status: JobStatus.PROCESSING },
    });

    logger.info(`[Job ${jobId}] Status updated to PROCESSING.`);

    const imageObject = await s3Client.send(
      new GetObjectCommand({
        Bucket: config.storage.bucketName,
        Key: savedFileName,
      })
    );

    if (!imageObject.Body) {
      logger.error(`[Job ${jobId}] No response body from S3.`);

      throw new Error("No response body from S3");
    }

    const imageObjectStream = Readable.fromWeb(
      imageObject.Body.transformToWebStream()
    );

    const thumbnailStream = generateThumbnail(imageObjectStream);

    const uploadThumbnail = new Upload({
      client: s3Client,
      params: {
        Bucket: config.storage.bucketName,
        Key: jobId,
        ContentType: "image/webp",
        Body: thumbnailStream,
      },
    });

    await uploadThumbnail.done();

    await db.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.SUCCEEDED,
        errorMessage: null,
      },
    });

    logger.info(`[Job ${jobId}] Status updated to SUCCEEDED.`);

    try {
      await s3Client.send(
        new DeleteObjectCommand({
          Bucket: config.storage.bucketName,
          Key: savedFileName,
        })
      );
      logger.info(`[Job ${jobId}] Original file deleted: ${savedFileName}`);
    } catch (unlinkErr) {
      logger.error(
        unlinkErr,
        `[Job ${jobId}] Error deleting original file ${savedFileName}`
      );
    }
  } catch (error) {
    await db.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.FAILED,
        errorMessage:
          error instanceof Error ? error.message : "Unknown processing error",
      },
    });

    logger.error(error, `[Job ${jobId}] Processing failed`);

    throw error;
  }
};

const jobsProcessor = { processThumbnailJob };

export { jobsProcessor };
