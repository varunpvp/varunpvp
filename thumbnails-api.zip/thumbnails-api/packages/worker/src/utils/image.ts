import { Readable } from "node:stream";
import { logger } from "../config/logger";
import sharp from "sharp";

const THUMBNAIL_SIZE = 100; // Target size (100x100)

const generateThumbnail = (inputStream: Readable): Readable => {
  try {
    const thumbnailGenerator = sharp()
      .resize(THUMBNAIL_SIZE, THUMBNAIL_SIZE, {
        fit: "cover",
        position: sharp.strategy.attention, // Or "entropy"
      })
      .webp()
      .on("error", (err) => {
        logger.error(err, "Sharp processing error");
        inputStream.destroy();
      });

    return inputStream.pipe(thumbnailGenerator);
  } catch (error) {
    logger.error(error, `Error processing image with sharp`);
    throw error;
  }
};

export { generateThumbnail };
