const config = {
  env: process.env.NODE_ENV!,
  port: parseInt(process.env.API_PORT!, 10),
  redis: {
    host: process.env.REDIS_HOST!,
    port: parseInt(process.env.REDIS_PORT!, 10),
  },
  storage: {
    endpoint: process.env.STORAGE_ENDPOINT!,
    accessKey: process.env.STORAGE_ACCESS_KEY!,
    secretKey: process.env.STORAGE_SECRET_KEY!,
    bucketName: process.env.STORAGE_BUCKET_NAME!,
  },
  workerQueueName: process.env.WORKER_QUEUE_NAME!,
  workerConcurrency: parseInt(process.env.WORKER_CONCURRENCY!, 10),
};

export { config };
