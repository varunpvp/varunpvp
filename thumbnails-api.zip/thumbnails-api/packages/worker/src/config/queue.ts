import { Worker } from "bullmq";
import { config } from ".";
import { jobsProcessor } from "../jobs/jobs.processor";
import { logger } from "./logger";

logger.info(`Worker listening on queue "${config.workerQueueName}"`);
logger.info(`Worker Concurrency: ${config.workerConcurrency}`);

const worker = new Worker(
  config.workerQueueName,
  async (job) => {
    logger.info(`[Job ${job.id}] Received job in worker wrapper.`);
    await jobsProcessor.processThumbnailJob(job.data);
  },
  {
    connection: {
      host: config.redis.host,
      port: config.redis.port,
    },
    autorun: true,
    concurrency: config.workerConcurrency,
  }
);

worker.on("completed", (job) => {
  logger.info(`[Job ${job.id}] Completed successfully.`);
});

worker.on("failed", (job, error) => {
  if (job) {
    logger.error(error, `[Job ${job.id}] Failed with error`);
  } else {
    logger.error(error, `Worker encountered an error with an undefined job`);
  }
});

const shutdownWorker = async () => {
  logger.info("Closing Worker...");
  await worker.close();
  await worker.disconnect();
  logger.info("Worker closed.");
};

export { worker, shutdownWorker };
