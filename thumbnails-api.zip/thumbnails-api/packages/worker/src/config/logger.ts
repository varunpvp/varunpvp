import pino from "pino";
import { config } from ".";

const logger = pino({
  level: config.env === "test" ? "silent" : "info",
});

export { logger };
