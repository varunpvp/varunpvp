/** @type {import('pino-pretty').PrettyOptions} */
module.exports = {
  messageFormat: (log, key) => {
    if (log.req && log.res) {
      return `${log.req.method} ${log.req.url} - ${log.res.statusCode} - ${log.responseTime}ms`;
    }

    return log[key];
  },
  ignore: "req,res,responseTime",
};
