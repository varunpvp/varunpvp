import { PrismaClient } from "@prisma/client";
import { logger } from "./logger";

const db = new PrismaClient();

const shutdownDb = async () => {
  await db.$disconnect();
  logger.info("db disconnected.");
};

export { db, shutdownDb };
