import { S3Client } from "@aws-sdk/client-s3";

import { config } from ".";

const s3Client = new S3Client({
  endpoint: config.storage.endpoint,
  region: "us-east-1", // dummy region, required by SDK. Not needed for MinIO
  forcePathStyle: true, // needed for MinIO
  credentials: {
    accessKeyId: config.storage.accessKey,
    secretAccessKey: config.storage.secretKey,
  },
});

export { s3Client };
