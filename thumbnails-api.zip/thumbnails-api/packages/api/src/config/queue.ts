import { Queue } from "bullmq";
import { config } from ".";
import { logger } from "./logger";

const thumbnailQueue = new Queue(config.workerQueueName, {
  connection: {
    host: config.redis.host,
    port: config.redis.port,
  },
  defaultJobOptions: {
    attempts: 3, // retry failed jobs 3 times
    backoff: {
      type: "exponential",
      delay: 1000, // initial delay 1s, doubles each attempt
    },
    removeOnComplete: true,
    removeOnFail: true,
  },
});

const shutdownThumbnailQueue = async () => {
  await thumbnailQueue.close();
  await thumbnailQueue.disconnect();
  logger.info(`${config.workerQueueName} queue closed.`);
};

export { thumbnailQueue, shutdownThumbnailQueue };
