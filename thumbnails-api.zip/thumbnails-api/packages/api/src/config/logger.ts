import pino from "pino";
import pinoHttp from "pino-http";
import { config } from ".";

const logger = pino({
  level: config.env === "test" ? "silent" : "info",
});

const httpLogger = pinoHttp({
  logger,
});

export { httpLogger, logger };
