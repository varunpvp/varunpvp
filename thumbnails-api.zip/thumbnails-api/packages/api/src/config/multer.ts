import path from "node:path";
import crypto from "node:crypto";

import multer from "multer";
import multerS3 from "multer-s3";

import { config } from ".";
import { s3Client } from "./storage";

const uploadImageFile = multer({
  limits: {
    files: 1,
    fileSize: 12 * 1024 * 1024, // 12MB limit
  },
  fileFilter(_req, file, callback) {
    if (!file.mimetype.startsWith("image/")) {
      callback(new Error("Unsupported file type"));
    }

    callback(null, true);
  },
  storage: multerS3({
    s3: s3Client,
    bucket: config.storage.bucketName,
    key: (_req, file, cb) => {
      const sanitizedName = path
        .basename(file.originalname)
        .replace(/[^a-zA-Z0-9]/g, "-")
        .toLowerCase();
      const uniqueId = crypto.randomUUID();
      cb(null, `${uniqueId}-${sanitizedName}`);
    },
  }),
});

export { uploadImageFile };
