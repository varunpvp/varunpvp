import { logger } from "./config/logger";
import { app } from "./app";
import { config } from "./config";
import { shutdownDb } from "./config/db";
import { shutdownThumbnailQueue } from "./config/queue";

const server = app.listen(config.port, () => {
  logger.info(`API Server listening on port ${config.port}`);
  logger.info(`Environment: ${config.env}`);
});

let isShuttingDown = false;

const gracefulShutdown = async (signal: string) => {
  if (isShuttingDown) {
    logger.info("Graceful shutdown already in progress. Ignoring signal.");
    return;
  }

  isShuttingDown = true;

  logger.info(`\nReceived ${signal}. Starting graceful shutdown...`);

  // stop accepting new connections
  server.close(async (err) => {
    if (err) {
      logger.error(err, "Error closing server");
      process.exit(1);
    }

    logger.info("HTTP server closed.");

    // close database connections
    try {
      await shutdownDb();
    } catch (dbErr) {
      logger.error(dbErr, "Error disconnecting Prisma");
    }

    // close queue connections
    try {
      await shutdownThumbnailQueue();
    } catch (queueErr) {
      logger.error(queueErr, "Error closing BullMQ queue");
    }

    // exit process
    logger.info("Graceful shutdown complete.");
    process.exit(0);
  });
};

// listen for termination signals
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));

process.on("unhandledRejection", (error) => {
  logger.error(error, "Unhandled Rejection");
});

process.on("uncaughtException", (error) => {
  logger.error(error, "Uncaught Exception");
});
