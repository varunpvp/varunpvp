import express from "express";

const handleRequest = (
  handler: express.RequestHandler
): express.RequestHandler => {
  return async (req, res, next) => {
    try {
      await handler(req, res, next);
    } catch (error) {
      // Pass errors to the global error handler
      next(error);
    }
  };
};

export { handleRequest };
