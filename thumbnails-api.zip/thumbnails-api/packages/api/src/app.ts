import express from "express";
import cors from "cors";

import { errorHandler } from "./middleware/error-handler";
import { apiRouter } from "./api";
import { httpLogger } from "./config/logger";

const app = express();

// middleware
app.use(cors({ origin: "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(httpLogger);

// health check endpoint
app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
});

app.use("/api/v1/", apiRouter);

// catch 404 errors
app.use((_req, res) => {
  res.status(404).json({ status: "error", error: { message: "Not Found" } });
});

// global error handler
app.use(errorHandler);

export { app };
