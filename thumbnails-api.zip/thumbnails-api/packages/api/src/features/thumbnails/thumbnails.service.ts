import { Readable } from "node:stream";

import { GetObjectCommand } from "@aws-sdk/client-s3";

import { config } from "../../config";
import { s3Client } from "../../config/storage";

const getThumbnailStream = async (jobId: string): Promise<Readable> => {
  const command = new GetObjectCommand({
    Bucket: config.storage.bucketName,
    Key: jobId,
  });

  const thumbnailObject = await s3Client.send(command);

  if (!thumbnailObject?.Body) {
    throw new Error("No response body from S3");
  }

  const webStream = thumbnailObject.Body.transformToWebStream();

  const nodeStream = Readable.fromWeb(webStream);

  return nodeStream;
};

const thumbnailsService = {
  getThumbnailStream,
};

export { thumbnailsService };
