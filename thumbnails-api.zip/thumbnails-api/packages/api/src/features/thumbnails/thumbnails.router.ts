import express from "express";
import { thumbnailsController } from "./thumbnails.controller";

const thumbnailsRouter = express.Router();

thumbnailsRouter.get("/:jobId", thumbnailsController.getThumbnail);

export { thumbnailsRouter };
