import { z } from "zod";

import { handleRequest } from "../../utils/async-handler";
import { thumbnailsService } from "./thumbnails.service";
import { logger } from "../../config/logger";

const getThumbnail = handleRequest(async (req, res) => {
  const pathParams = await z
    .object({ jobId: z.string().uuid() })
    .safeParseAsync(req.params);

  if (!pathParams.success) {
    return res.status(400).json({
      message: "Invalid Job ID format.",
    });
  }

  try {
    const thumbnailStream = await thumbnailsService.getThumbnailStream(
      pathParams.data.jobId
    );

    res.setHeader("Content-Type", `image/webp`);
    res.setHeader("Cache-Control", "public, max-age=3600");

    thumbnailStream
      .on("error", (error) => {
        logger.error(
          error,
          `Stream error for job thumbnail ${pathParams.data.jobId}`
        );

        if (!res.headersSent) {
          res.status(500).json({
            status: "error",
            error: {
              message: "Error streaming thumbnail",
            },
          });
        }

        res.end();
      })
      .pipe(res);
  } catch (error) {
    logger.error(error, "Error fetching thumbnail");

    return res.status(404).json({
      message: `Thumbnail for job ID ${pathParams.data.jobId} not found or not ready.`,
    });
  }
});

const thumbnailsController = {
  getThumbnail,
};

export { thumbnailsController };
