import crypto from "node:crypto";
import path from "node:path";

import request from "supertest";
import { JobStatus } from "@prisma/client";

import { app } from "../../../app";
import { thumbnailQueue, shutdownThumbnailQueue } from "../../../config/queue";
import { db, shutdownDb } from "../../../config/db";

const testImageFilePath = path.join(__dirname, "./fixtures/test-image.png");
const nonImageFilePath = path.join(__dirname, "./fixtures/test-file.txt");

describe("Jobs API Integration Tests", () => {
  beforeAll(async () => {
    // Clear existing data
    await thumbnailQueue.obliterate({ force: true });
    await db.job.deleteMany({});
  });

  afterEach(async () => {
    await thumbnailQueue.obliterate({ force: true });
    await db.job.deleteMany({});
  });

  afterAll(async () => {
    await shutdownDb();
    await shutdownThumbnailQueue();
  });

  describe("POST /api/v1/jobs", () => {
    it("should return 202 Accepted and jobId on successful image upload", async () => {
      const response = await request(app)
        .post("/api/v1/jobs")
        .attach("image", testImageFilePath);

      expect(response.status).toBe(202);
      expect(response.body.status).toBe("success");
      expect(response.body.data).toHaveProperty("id");
      expect(response.body.data).toHaveProperty("savedFileName");

      const jobId = response.body.data.id;

      // verify database record
      const dbJob = await db.job.findUnique({
        where: { id: jobId },
      });

      expect(dbJob).not.toBeNull();
      expect(dbJob?.status).toBe(JobStatus.PENDING);
      expect(dbJob?.originalFileName).toBe("test-image.png");

      // verify queue job
      const queueJobs = await thumbnailQueue.getWaiting();

      expect(queueJobs).toHaveLength(1);
      expect(queueJobs[0].data.jobId).toBe(jobId);
      expect(queueJobs[0].data.savedFileName).toBe(dbJob?.savedFileName);
    });

    it("should return 400 Bad Request if no image file is provided", async () => {
      const response = await request(app).post("/api/v1/jobs").send({});

      expect(response.status).toBe(400);
      expect(response.body.status).toBe("error");
      expect(response.body.error.message).toBe("No image file provided");
    });

    it("should return 400 Bad Request if file is not an image", async () => {
      const response = await request(app)
        .post("/api/v1/jobs")
        .attach("image", nonImageFilePath);

      expect(response.status).toBe(400);
      expect(response.body.status).toBe("error");
      expect(response.body.error.message).toBe(
        "Unsupported file type or file size to large"
      );
    });
  });

  describe("GET /api/v1/jobs/:jobId", () => {
    it("should return 200 OK and job status for a valid jobId", async () => {
      const createdJob = await db.job.create({
        data: {
          fileMimeType: "image/png",
          savedFileName: "tset.png",
          fileSize: 5000,
          originalFileName: "test.png",
          status: JobStatus.PENDING,
        },
      });
      const jobId = createdJob.id;

      const response = await request(app).get(`/api/v1/jobs/${jobId}`);

      expect(response.status).toBe(200);
      expect(response.body.status).toBe("success");
      expect(response.body.data.id).toBe(createdJob.id);
      expect(response.body.data.status).toBe(createdJob.status);
      expect(response.body.data.savedFileName).toBe(createdJob.savedFileName);
    });

    it("should return 404 Not Found for a non-existent jobId", async () => {
      const nonExistentJobId = crypto.randomUUID();

      const response = await request(app).get(
        `/api/v1/jobs/${nonExistentJobId}`
      );

      expect(response.status).toBe(404);

      expect(response.body.status).toBe("error");
    });

    it("should return 400 Bad Request for an invalid jobId format", async () => {
      const invalidJobId = "invalid-id-format";

      const response = await request(app).get(`/api/v1/jobs/${invalidJobId}`);

      expect(response.status).toBe(400);
      expect(response.body.status).toBe("error");
    });
  });

  describe("GET /api/v1/jobs", () => {
    it("should return 200 OK and an array of jobs", async () => {
      await db.job.createMany({
        data: [
          {
            originalFileName: "test1.png",
            savedFileName: "saved-test1.png",
            fileMimeType: "image/png",
            fileSize: 10000,
            status: JobStatus.SUCCEEDED,
          },
          {
            originalFileName: "test2.jpg",
            savedFileName: "saved-test2.jpg",
            fileMimeType: "image/jpeg",
            fileSize: 12000,
            status: JobStatus.PENDING,
          },
        ],
      });

      const response = await request(app).get("/api/v1/jobs");

      expect(response.status).toBe(200);
      expect(response.body.status).toBe("success");

      expect(Array.isArray(response.body.data)).toBe(true);

      expect(response.body.data.length).toBe(2);

      // Check structure of one element
      expect(response.body.data[0]).toHaveProperty("id");
      expect(response.body.data[0]).toHaveProperty("status");
      expect(response.body.data[0]).toHaveProperty("savedFileName");
      expect(response.body.data[0]).toHaveProperty("createdAt");

      expect(response.body.meta).toHaveProperty("total");
    });

    it("should return an empty array if no jobs exist", async () => {
      const response = await request(app).get("/api/v1/jobs");

      expect(response.status).toBe(200);
      expect(response.body.status).toBe("success");

      expect(response.body.data).toEqual([]);
    });
  });
});
