import { Job, JobStatus } from "@prisma/client";
import { db } from "../../config/db";
import { thumbnailQueue } from "../../config/queue";
import { config } from "../../config";
import { logger } from "../../config/logger";

const addJobToQueue = async (params: {
  savedFileName: string;
  originalFileName: string;
  fileSize: number;
  fileMimeType: string;
}): Promise<Job> => {
  const job = await db.job.create({
    data: {
      savedFileName: params.savedFileName,
      originalFileName: params.originalFileName,
      fileSize: params.fileSize,
      fileMimeType: params.fileMimeType,
      status: JobStatus.PENDING,
    },
  });

  await thumbnailQueue.add(
    config.workerQueueName,
    {
      jobId: job.id,
      savedFileName: params.savedFileName,
    },
    { jobId: job.id }
  );

  logger.info(`Added job ${job.id} to queue ${config.workerQueueName}`);

  return job;
};

const getJobById = async (jobId: string): Promise<Job | null> => {
  const job = await db.job.findUnique({
    where: { id: jobId },
  });

  return job;
};

const getPaginatedJobs = async (params: {
  page: number;
  pageSize: number;
}): Promise<{ jobs: Job[]; total: number }> => {
  const jobs = await db.job.findMany({
    take: params.pageSize,
    skip: params.page * params.pageSize,
    orderBy: {
      createdAt: "desc",
    },
  });

  const total = await db.job.count();

  return {
    jobs,
    total,
  };
};

const jobsService = {
  addJobToQueue,
  getJobById,
  getPaginatedJobs,
};

export { jobsService };
