import { DeleteObjectCommand } from "@aws-sdk/client-s3";
import { z } from "zod";
import { jobsService } from "./jobs.service";
import { handleRequest } from "../../utils/async-handler";
import { config } from "../../config";
import { s3Client } from "../../config/storage";
import { logger } from "../../config/logger";

const createJob = handleRequest(async (req, res) => {
  const imageFile = await z
    .object({
      originalname: z.string(),
      size: z.number(),
      mimetype: z.string(),
      key: z.string(),
    })
    .safeParseAsync(req.file);

  if (!imageFile.success) {
    return res.status(400).json({
      status: "error",
      error: {
        message: "No image file provided",
      },
    });
  }

  try {
    const job = await jobsService.addJobToQueue({
      originalFileName: imageFile.data.originalname,
      savedFileName: imageFile.data.key,
      fileSize: imageFile.data.size,
      fileMimeType: imageFile.data.mimetype,
    });

    return res.status(202).json({ status: "success", data: job });
  } catch (error) {
    try {
      await s3Client.send(
        new DeleteObjectCommand({
          Bucket: config.storage.bucketName,
          Key: imageFile.data.key,
        })
      );
    } catch {
      logger.error(error, `Cleanup failed for file ${imageFile.data.key}`);
    }

    logger.error(
      error,
      `Failed to create thumbnail job for file ${imageFile.data.originalname}`
    );

    return res.json({
      status: "error",
      error: {
        message: "Unknown error occured while processing the request",
      },
    });
  }
});

const getJob = handleRequest(async (req, res) => {
  const pathParams = await z
    .object({ jobId: z.string().uuid() })
    .safeParseAsync(req.params);

  if (!pathParams.success) {
    return res.status(400).json({
      status: "error",
      error: {
        message: "Invalid Job ID format.",
      },
    });
  }

  const { jobId } = pathParams.data;

  const job = await jobsService.getJobById(jobId);

  if (!job) {
    return res.status(404).json({
      status: "error",
      error: {
        message: `Job with ID ${jobId} not found.`,
      },
    });
  }

  return res.status(200).json({
    status: "success",
    data: job,
  });
});

const listJobs = handleRequest(async (req, res) => {
  const queryParams = await z
    .object({
      page: z.coerce.number().nonnegative().catch(0),
      pageSize: z.coerce.number().nonnegative().catch(10),
    })
    .safeParseAsync(req.query);

  if (!queryParams.success) {
    return res.status(400).json({
      status: "error",
      error: {
        message: "Invalid query parameters.",
      },
    });
  }

  const { jobs, total } = await jobsService.getPaginatedJobs({
    page: queryParams.data.page,
    pageSize: queryParams.data.pageSize,
  });

  return res.status(200).json({
    status: "success",
    data: jobs,
    meta: {
      page: queryParams.data.page,
      pageSize: queryParams.data.pageSize,
      total,
      totalPages: total > 0 ? Math.ceil(total / queryParams.data.pageSize) : 0,
    },
  });
});

const jobsController = {
  createJob,
  getJob,
  listJobs,
};

export { jobsController };
