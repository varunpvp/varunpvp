import express from "express";
import { jobsController } from "./jobs.controller";
import { uploadImageFile } from "../../config/multer";

const jobsRouter = express.Router();

jobsRouter.post(
  "/",
  (req, res, next) => {
    uploadImageFile.single("image")(req, res, (error) => {
      if (error) {
        return res.status(400).json({
          status: "error",
          error: {
            message: "Unsupported file type or file size to large",
          },
        });
      }

      next();
    });
  },
  jobsController.createJob
);

jobsRouter.get("/:jobId", jobsController.getJob);

jobsRouter.get("/", jobsController.listJobs);

export { jobsRouter };
