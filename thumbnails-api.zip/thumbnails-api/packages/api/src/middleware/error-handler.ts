import { logger } from "../config/logger";
import { Request, Response, NextFunction } from "express";

const errorHandler = (
  error: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
) => {
  logger.error(error, "Unhandled Error");

  // Customize error response based on error type if needed
  // Example: Handle Prisma errors
  // if (err instanceof Prisma.PrismaClientKnownRequestError) {
  //   statusCode = 400; // Or appropriate code based on Prisma error code
  //   message = `Database Error: ${err.code}`;
  // }

  // Example: Handle Zod validation errors
  // if (err instanceof ZodError) {
  //   statusCode = 400;
  //   message = 'Validation Error';
  //   return res.status(statusCode).json({ message, errors: err.errors });
  // }

  res.status(500).json({
    status: "error",
    error: {
      message: "Internal Server Error",
    },
  });
};

export { errorHandler };
