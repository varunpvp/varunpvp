import express from "express";
import { jobsRouter } from "./features/jobs/jobs.router";
import { thumbnailsRouter } from "./features/thumbnails/thumbnails.router";

const apiRouter = express.Router();

// routers
apiRouter.use("/jobs", jobsRouter);
apiRouter.use("/thumbnails", thumbnailsRouter);

export { apiRouter };
