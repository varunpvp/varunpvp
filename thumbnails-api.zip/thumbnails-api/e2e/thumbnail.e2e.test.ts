import path from "node:path";
import request from "supertest";
import { JobStatus } from "@prisma/client";

import { db, shutdownDb as shutdownApiDb } from "../packages/api/src/config/db";
import { shutdownDb as shutdownWorkerDb } from "../packages/worker/src/config/db";
import {
  thumbnailQueue,
  shutdownThumbnailQueue,
} from "../packages/api/src/config/queue";
import { shutdownWorker } from "../packages/worker/src/config/queue";
import { app } from "../packages/api/src/app";

const TEST_FILES_DIR = path.join(__dirname, "fixtures");
const validImagePath = path.join(TEST_FILES_DIR, "test-image.png");
const corruptedImagePath = path.join(TEST_FILES_DIR, "corrupted-image.jpg");
const nonImagePath = path.join(TEST_FILES_DIR, "test-file.txt");

describe("Thumbnail API E2E Tests", () => {
  afterEach(async () => {
    await thumbnailQueue.obliterate({ force: true });
    await db.job.deleteMany({});
  });

  afterAll(async () => {
    await Promise.allSettled([
      shutdownApiDb(),
      shutdownWorkerDb(),
      shutdownWorker(),
      shutdownThumbnailQueue(),
    ]);
  });

  describe("Thumbnail Generation Flow", () => {
    it("should successfully process a valid image", async () => {
      // 1. Upload image
      const response = await request(app)
        .post("/api/v1/jobs")
        .attach("image", validImagePath)
        .expect(202);

      const jobId = response.body.data.id;

      expect(jobId).toBeDefined();

      // 2. Wait for job completion (with timeout)
      const maxAttempts = 5;
      const interval = 1000;
      let attempts = 0;
      let jobStatus;

      while (attempts < maxAttempts) {
        const statusResponse = await request(app)
          .get(`/api/v1/jobs/${jobId}`)
          .expect(200);

        jobStatus = statusResponse.body.data.status;

        if (
          jobStatus === JobStatus.SUCCEEDED ||
          jobStatus === JobStatus.FAILED
        ) {
          break;
        }

        await new Promise((resolve) => setTimeout(resolve, interval));

        attempts++;
      }

      expect(jobStatus).toBe(JobStatus.SUCCEEDED);

      // 3. Verify job in database
      const job = await db.job.findUnique({
        where: { id: jobId },
      });

      expect(job).toBeDefined();
      expect(job?.status).toBe(JobStatus.SUCCEEDED);
      expect(job?.errorMessage).toBeNull();

      // 4. Download and verify thumbnail
      const thumbnailResponse = await request(app)
        .get(`/api/v1/thumbnails/${jobId}`)
        .expect(200)
        .expect("Content-Type", "image/webp");

      expect(thumbnailResponse.body).toBeDefined();
      expect(thumbnailResponse.body.length).toBeGreaterThan(0);
    });

    it("should handle invalid file uploads", async () => {
      await request(app)
        .post("/api/v1/jobs")
        .attach("image", nonImagePath)
        .expect(400);

      const jobs = await db.job.findMany();

      expect(jobs).toHaveLength(0);
    });

    it("should handle corrupted image processing", async () => {
      const response = await request(app)
        .post("/api/v1/jobs")
        .attach("image", corruptedImagePath)
        .expect(202);

      const jobId = response.body.data.id;

      // Wait for job failure
      let job;
      do {
        await new Promise((resolve) => setTimeout(resolve, 1000));
        job = await db.job.findUnique({ where: { id: jobId } });
      } while (
        job?.status === JobStatus.PENDING ||
        job?.status === JobStatus.PROCESSING
      );

      expect(job?.status).toBe(JobStatus.FAILED);
      expect(job?.errorMessage).toBeDefined();

      // Verify thumbnail is not accessible
      await request(app).get(`/api/v1/thumbnails/${jobId}`).expect(404);
    });
  });
});
