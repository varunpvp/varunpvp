import { RequestHandler } from "express";
import jwtSimple, { TAlgorithm } from "jwt-simple";
import AuthRequest from "../types/auth-request";

const authenticate: () => RequestHandler = () => (req, res, next) => {
    try {
        const token = req.get("authorization");
        if (!token) {
            return res.sendStatus(401);
        }

        const jwt = token.replace(/^Bearer\s+/gi, "");

        if (!jwt) {
            return res.sendStatus(401);
        }

        try {
            const payload = jwtSimple.decode(jwt, process.env.JWT_SECRET!, false, process.env.JWT_ALGO! as TAlgorithm);

            (req as AuthRequest).user = payload;

            return next();
        } catch (e) {
            return res.sendStatus(401);
        }
    } catch (error) {
        next(error);
    }
};

export default authenticate;
