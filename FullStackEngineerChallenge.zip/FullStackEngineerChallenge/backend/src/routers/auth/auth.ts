import express from "express";
import database from "../../config/database";
import md5 from "md5";
import jwt from "jwt-simple";
import { User } from ".prisma/client";

const authRouter = express();

authRouter.post("/token", async (req, res, next) => {
    try {
        const { email, password } = req.body;

        const user = await database.user.findFirst({
            where: {
                OR: [{ email }],
            },
        });

        if (!user) {
            return res.sendStatus(401);
        }

        const hash = md5(password);

        if (hash !== user.password) {
            return res.sendStatus(401);
        }

        const token = generateToken(user);

        return res.json({ token });
    } catch (error) {
        next(error);
    }
});

function generateToken(user: User) {
    const payload = {
        id: user.id,
        email: user.email,
        name: user.name,
        gender: user.gender,
        role: user.role,
    };
    return jwt.encode(payload, process.env.JWT_SECRET!);
}

export default authRouter;
