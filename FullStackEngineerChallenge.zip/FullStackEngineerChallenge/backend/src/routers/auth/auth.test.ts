import app from "../../app";
import request from "supertest";

describe("POST /auth/token", () => {
    it("should return 200 OK", () => {
        return request(app).post("/auth/token").field("email", "admin@test.com").field("password", "password").expect(401);
    });
});

describe("POST /auth/token", () => {
    it("should return 410 Unauthorized", () => {
        return request(app).post("/auth/token").field("email", "user@gmail.com").field("password", "password").expect(401);
    });
});
