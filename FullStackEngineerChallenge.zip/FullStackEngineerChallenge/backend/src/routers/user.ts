import { UserRole } from ".prisma/client";
import express from "express";
import database from "../config/database";
import md5 from "md5";
import { userFieldsToSelect } from "../utils/database";

const userRouter = express.Router();

userRouter.get("/", async (_, res, next) => {
    try {
        const users = await database.user.findMany({ select: userFieldsToSelect });

        res.json({ users });
    } catch (error) {
        next(error);
    }
});

userRouter.post("/", async (req, res, next) => {
    try {
        const { email, gender, name, password: textPassword } = req.body;

        const hashedPassword = md5(textPassword);

        const employee = await database.user.create({
            select: userFieldsToSelect,
            data: {
                email,
                gender,
                name,
                password: hashedPassword,
                role: UserRole.EMPLOYEE,
            },
        });

        res.json({ users: [employee] });
    } catch (error) {
        next(error);
    }
});

userRouter.get<{ id: string }>("/:id", async (req, res, next) => {
    try {
        const employee = await database.user.findFirst({ select: userFieldsToSelect, where: { id: Number(req.params.id) } });

        if (!employee) {
            return res.sendStatus(404);
        }

        res.json({ users: [employee] });
    } catch (error) {
        next(error);
    }
});

userRouter.put<{ id: string }>("/:id", async (req, res, next) => {
    try {
        const { email, gender, name, password: textPassword } = req.body;

        const hashedPassword = textPassword ? md5(textPassword) : undefined;

        const employee = await database.user.update({
            select: userFieldsToSelect,
            data: {
                email,
                gender,
                name,
                ...(hashedPassword && { password: hashedPassword }),
            },
            where: {
                id: Number(req.params.id),
            },
        });

        res.json({ users: [employee] });
    } catch (error) {
        next(error);
    }
});

userRouter.delete<{ id: string }>("/:id", async (req, res, next) => {
    try {
        const id = req.params.id;
        await database.$queryRaw`DELETE FROM user WHERE id = ${id}`;
        await database.$queryRaw`DELETE FROM review WHERE user_id = ${id} or reviewee_id = ${id}`;
        await database.$queryRaw`DELETE FROM review_request WHERE user_id = ${id} or reviewee_id = ${id}`;
        res.sendStatus(200);
    } catch (error) {
        next(error);
    }
});

export default userRouter;
