import express from "express";
import database from "../config/database";

const reviewRouter = express.Router();

reviewRouter.get("/", async (req, res, next) => {
    try {
        const userId = Number(req.query.userId as string);
        const revieweeId = Number(req.query.revieweeId as string);

        const reviews = await database.review.findMany({ where: { ...(userId && { userId }), ...(revieweeId && { revieweeId }) } });

        res.json({ reviews });
    } catch (error) {
        next(error);
    }
});

reviewRouter.post("/", async (req, res, next) => {
    try {
        const { rating, text, revieweeId, userId } = req.body;

        if (!revieweeId || !userId) {
            return res.sendStatus(400);
        }

        const review = await database.review.create({
            data: {
                rating,
                text,
                revieweeId,
                userId,
            },
        });

        await database.reviewRequest.updateMany({ data: { isFulfilled: true }, where: { AND: { userId, revieweeId } } });

        res.json({ reviews: [review] });
    } catch (error) {
        next(error);
    }
});

reviewRouter.put<{ id: string }>("/:id", async (req, res, next) => {
    try {
        const { text, rating } = req.body;
        const review = await database.review.update({
            data: {
                text,
                rating,
            },
            where: {
                id: Number(req.params.id),
            },
        });
        res.json({ reviews: [review] });
    } catch (error) {
        next(error);
    }
});

export default reviewRouter;
