import express from "express";
import database from "../config/database";
import { userFieldsToSelect } from "../utils/database";

const reviewRequestRouter = express.Router();

reviewRequestRouter.get("/", async (req, res, next) => {
    try {
        if (!req.query.userId) {
            return res.sendStatus(400);
        }

        const userId = Number(req.query.userId as string);

        const reviewRequests = await database.reviewRequest.findMany({
            where: { userId, isFulfilled: false },
        });

        const revieweeIds = reviewRequests.map((it) => it.revieweeId);

        const reviewees = await database.user.findMany({ select: userFieldsToSelect, where: { id: { in: revieweeIds } } });

        res.json({ reviewRequests, users: reviewees });
    } catch (error) {
        next(error);
    }
});

reviewRequestRouter.post("/", async (req, res, next) => {
    try {
        const { userId, revieweeId } = req.body;

        const reviewRequest = await database.reviewRequest.findFirst({
            where: { userId, revieweeId },
            include: { reviewee: true },
        });

        if (reviewRequest) {
            if (reviewRequest.isFulfilled) {
                return res.json({ message: `${reviewRequest.reviewee.name} already has been reviewed.` });
            } else {
                return res.json({
                    message: `A review request is already sent.`,
                });
            }
        }

        const reviewRequestRecord = await database.reviewRequest.create({ data: { userId, revieweeId } });

        const reviewee = await database.user.findFirst({ select: userFieldsToSelect, where: { id: reviewRequestRecord.revieweeId } });

        res.json({ message: "Review request successfully!", reviewRequests: [reviewRequestRecord], users: [reviewee] });
    } catch (error) {
        next(error);
    }
});

export default reviewRequestRouter;
