import express from "express";
import compression from "compression";
import bodyParser from "body-parser";
import cors from "cors";

import authRouter from "./routers/auth/auth";
import userRouter from "./routers/user";
import reviewRouter from "./routers/review";
import reviewRequestRouter from "./routers/review-request";
import authenticate from "./middlewares/authenticate";

const app = express();

app.set("port", process.env.PORT || 3000);

app.use(cors());
app.use(compression());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (_, res) => res.send("It works!"));

app.use("/auth", authRouter);
app.use("/user", authenticate(), userRouter);
app.use("/review", authenticate(), reviewRouter);
app.use("/review-request", authenticate(), reviewRequestRouter);

export default app;
