export const userFieldsToSelect = { id: true, role: true, name: true, email: true, gender: true, updatedAt: true, createdAt: true };
