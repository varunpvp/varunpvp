import { PrismaClient } from "@prisma/client";
import md5 from "md5";
const database = new PrismaClient();

const password = md5("password");

async function main() {
    await database.user.createMany({
        data: [
            { name: "Admin", email: "admin@test.com", role: "ADMIN", gender: "MALE", password },
            { name: "John", email: "john@test.com", role: "EMPLOYEE", gender: "MALE", password },
            { name: "Alice", email: "alice@test.com", role: "EMPLOYEE", gender: "FEMALE", password },
            { name: "Mike", email: "mike@test.com", role: "EMPLOYEE", gender: "MALE", password },
        ],
    });
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await database.$disconnect();
    });
