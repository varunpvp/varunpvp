-- AlterTable
ALTER TABLE `review` MODIFY `text` TEXT NOT NULL;

-- AlterTable
ALTER TABLE `review_request` ADD COLUMN `is_fulfilled` BOOLEAN NOT NULL DEFAULT false;
