# Assumptions

- Admin will be able to request employees to review other employees including himself.
- Admin can only request a employee's review once.
- Admins and employees will see a list of pending review requests and will be able to add their reviews.

# Getting started with local setup

## Tech stack used

- React (Ant Design, Mobx)
- NodeJS (Express.js, Prisma.js)
- MySQL

## Backend setup

Before starting backend setup. Ensure `DATABASE_URL` is correctly set in `.env` file.

Then execute the sql files in `prisma/migrations` folder on connected database.

Run following command to start backend server.

```
$ npm install
$ npx prisma generate
$ npm run dev
```

The server will start and print `App started on on port 3000!` to the console.

## Frontend setup

Please run following commands.

```
$ yarn
$ yarn start
```

If API calls fail. Ensure `REACT_APP_API_BASE_URL` is correctly set in `.env` file.

If any issues please reach out to me at [varunpvp@gmail.com](mailto:varunpvp@gmail.com).
