const Forbidden = () => (
  <div className="flex flex-col justify-center items-center h-screen">
    Not allowed!
  </div>
);
export default Forbidden;
