import message from "antd/lib/message";
import PageHeader from "antd/lib/page-header";
import { observer } from "mobx-react";
import { useHistory, useParams } from "react-router";
import { useAppContext } from "../../app-context";
import ReviewForm from "../../components/review-form";

const ReviewAdd = () => {
  const history = useHistory();
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const context = useAppContext();
  const reviewRequest = context.store.reviewRequest.byId.get(id);

  return (
    <div className="mt-4">
      <PageHeader
        title={`Add Review for ${reviewRequest?.reviewee?.name}`}
        ghost={false}
        onBack={() => history.goBack()}
      />
      <div className="flex justify-center bg-white">
        <div style={{ width: 450 }}>
          <ReviewForm
            onFinish={async (values) => {
              try {
                await context.api.review.create({
                  userId: reviewRequest!.userId,
                  revieweeId: reviewRequest!.revieweeId,
                  ...values,
                });
                context.store.reviewRequest.remove(id);
                history.goBack();
              } catch (error) {
                console.error(error);
                message.error("Something went wrong");
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default observer(ReviewAdd);
