import message from "antd/lib/message";
import PageHeader from "antd/lib/page-header";
import { observer } from "mobx-react";
import { useHistory, useParams } from "react-router";
import { useAppContext } from "../../app-context";
import ReviewForm from "../../components/review-form";

const ReviewEdit = () => {
  const history = useHistory();
  const params = useParams<{ id: string }>();
  const context = useAppContext();
  const review = context.store.review.byId.get(Number(params.id));
  return (
    <div className="mt-4">
      <PageHeader
        title="Edit Review"
        ghost={false}
        onBack={() => history.goBack()}
      />
      <div className="flex justify-center bg-white">
        <div style={{ width: 450 }}>
          <ReviewForm
            values={review}
            onFinish={async (values) => {
              try {
                await context.api.review.update({
                  id: review!.id,
                  userId: review!.userId,
                  revieweeId: review!.revieweeId,
                  ...values,
                });
                history.goBack();
              } catch {
                message.error("Something went wrong");
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default observer(ReviewEdit);
