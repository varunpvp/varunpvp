import Button from "antd/lib/button";
import PageHeader from "antd/lib/page-header";
import Table, { ColumnsType } from "antd/lib/table/Table";
import { observer } from "mobx-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAppContext } from "../../app-context";
import ReviewRequest from "../../models/review-request";

const ReviewRequestPendingList = () => {
  const context = useAppContext();
  const [loading, setLoading] = useState(false);

  const columns: ColumnsType<ReviewRequest> = [
    {
      title: "Reviewee ID",
      key: "id",
      render: (_, record) => record.revieweeId,
    },
    {
      title: "Reviewee Name",
      key: "name",
      render: (_, record) => <a>{record.reviewee?.name}</a>,
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Button type="text">
          <Link to={`/review-request/${record.id}`}>Review now</Link>
        </Button>
      ),
    },
  ];

  const load = async () => {
    try {
      setLoading(true);
      await context.api.reviewRequest.getEmployeePendingRequests(
        context.store.auth.user!.id
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="mt-4">
      <PageHeader title={`Pending Review Requests`} ghost={false} />
      <Table
        pagination={false}
        columns={columns}
        dataSource={context.store.auth.user?.pendingReviewRequests}
        loading={loading}
      />
    </div>
  );
};

export default observer(ReviewRequestPendingList);
