import { Button, message, PageHeader } from "antd";
import ButtonGroup from "antd/lib/button/button-group";
import Table, { ColumnsType } from "antd/lib/table/Table";
import { observer } from "mobx-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAppContext } from "../../app-context";
import User from "../../models/user";
import ReviewRequestModal from "../../components/review-request-modal";

const EmployeeList = () => {
  const context = useAppContext();
  const [loading, setLoading] = useState(false);
  const [reviewRequestUserId, setReviewRequestUserId] =
    useState<undefined | number>();

  const columns: ColumnsType<User> = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Gender",
      dataIndex: "gender",
      key: "gender",
    },
    {
      align: "right",
      title: "Action",
      key: "action",
      render: (_, record) => (
        <ButtonGroup>
          <Button type="text">
            <Link to={`/employee/${record.id}/review`}>Show reviews</Link>
          </Button>
          <Button type="text" onClick={() => setReviewRequestUserId(record.id)}>
            Request review
          </Button>
          <Button type="text">
            <Link to={`/employee/${record.id}/edit`}>Edit</Link>
          </Button>
          <Button
            type="text"
            danger
            onClick={() => context.api.user.delete(record.id)}
          >
            Delete
          </Button>
        </ButtonGroup>
      ),
    },
  ];

  const load = async () => {
    try {
      setLoading(true);
      await context.api.user.getAll();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="mt-4">
      <PageHeader
        title="Employees"
        ghost={false}
        extra={
          <Button type="primary">
            <Link to="/employee/add">Add Employee</Link>
          </Button>
        }
      />
      <Table
        pagination={false}
        columns={columns}
        dataSource={context.store.user.all}
        loading={loading}
      />
      <ReviewRequestModal
        reviewRequestUserId={reviewRequestUserId}
        onClose={() => setReviewRequestUserId(undefined)}
      />
    </div>
  );
};

export default observer(EmployeeList);
