import message from "antd/lib/message";
import PageHeader from "antd/lib/page-header";
import { observer } from "mobx-react";
import { useHistory, useParams } from "react-router";
import { useAppContext } from "../../app-context";
import EmployeeForm from "../../components/employee-form";

const EmployeeEdit = () => {
  const history = useHistory();
  const params = useParams<{ id: string }>();
  const context = useAppContext();
  const employee = context.store.user.byId.get(Number(params.id));
  return (
    <div className="mt-4">
      <PageHeader
        title="Edit Employee"
        ghost={false}
        onBack={() => history.goBack()}
      />
      <div className="flex justify-center bg-white">
        <div style={{ width: 450 }}>
          <EmployeeForm
            editing
            values={employee}
            onFinish={async (values) => {
              try {
                await context.api.user.updateEmployee({
                  id: employee!.id,
                  ...values,
                });
                history.goBack();
              } catch {
                message.error("Something went wrong");
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default observer(EmployeeEdit);
