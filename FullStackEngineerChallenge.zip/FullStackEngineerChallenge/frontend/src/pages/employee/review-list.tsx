import Button from "antd/lib/button";
import PageHeader from "antd/lib/page-header";
import Rate from "antd/lib/rate";
import Table, { ColumnsType } from "antd/lib/table/Table";
import { observer } from "mobx-react";
import { useEffect, useState } from "react";
import { Link, useHistory, useParams } from "react-router-dom";
import { useAppContext } from "../../app-context";
import Review from "../../models/review";

const EmployeeReviewList = () => {
  const params = useParams<{ id: string }>();
  const history = useHistory();
  const id = Number(params.id);
  const context = useAppContext();
  const [loading, setLoading] = useState(false);
  const employee = context.store.user.byId.get(id);

  const columns: ColumnsType<Review> = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Reviewer Name",
      key: "name",
      render: (_, record) => <a>{record.user?.name}</a>,
    },
    {
      title: "Rating",
      key: "rating",
      render: (_, record) => <Rate disabled value={record.rating} />,
    },
    {
      title: "Comment",
      key: "address",
      render: (_, record) => record.text,
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Button type="text">
          <Link to={`/review/${record.id}`}>Edit</Link>
        </Button>
      ),
    },
  ];

  const load = async () => {
    try {
      setLoading(true);
      await context.api.review.getUserReceivedReview(id);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="mt-4">
      <PageHeader
        title={`${employee?.name} Reviews`}
        ghost={false}
        onBack={() => history.goBack()}
      />
      <Table
        pagination={false}
        columns={columns}
        dataSource={employee?.receivedReviews}
        loading={loading}
      />
    </div>
  );
};

export default observer(EmployeeReviewList);
