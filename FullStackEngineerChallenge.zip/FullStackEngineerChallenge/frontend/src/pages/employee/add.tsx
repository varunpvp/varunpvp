import message from "antd/lib/message";
import PageHeader from "antd/lib/page-header";
import { useHistory } from "react-router";
import { useAppContext } from "../../app-context";
import EmployeeForm from "../../components/employee-form";

const EmployeeAdd = () => {
  const history = useHistory();
  const context = useAppContext();
  return (
    <div className="mt-4">
      <PageHeader
        title="Add Employee"
        ghost={false}
        onBack={() => history.goBack()}
      />
      <div className="flex justify-center bg-white">
        <div style={{ width: 450 }}>
          <EmployeeForm
            onFinish={async (values) => {
              try {
                await context.api.user.createEmployee(values);
                history.goBack();
              } catch {
                message.error("Something went wrong");
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default EmployeeAdd;
