const NotFound = () => (
  <div className="flex flex-col justify-center items-center h-screen">
    Not Found!
  </div>
);
export default NotFound;
