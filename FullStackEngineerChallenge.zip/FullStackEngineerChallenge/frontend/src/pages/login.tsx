import Button from "antd/lib/button";
import Form from "antd/lib/form/Form";
import FormItem from "antd/lib/form/FormItem";
import Input from "antd/lib/input/Input";
import message from "antd/lib/message";
import { useState } from "react";
import { useAppContext } from "../app-context";
import Logo from "../components/logo";

const Login = () => {
  const context = useAppContext();
  const [loading, setLoading] = useState(false);

  return (
    <div className="flex flex-col justify-center items-center h-screen">
      <Logo />
      <div style={{ width: 320 }}>
        <Form<{ email: string; password: string }>
          onFinish={async ({ email, password }) => {
            try {
              setLoading(true);
              await context.api.auth.signin(email, password);
            } catch (error) {
              console.log(error);
              message.error("Something went wrong!");
              setLoading(false);
            }
          }}
        >
          <FormItem name="email" rules={[{ required: true }]} hasFeedback>
            <Input type="email" placeholder={`Email`} />
          </FormItem>
          <FormItem name="password" rules={[{ required: true }]} hasFeedback>
            <Input type="password" placeholder={`Password`} />
          </FormItem>

          <Button block type="primary" htmlType="submit" loading={loading}>
            Sign in
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default Login;
