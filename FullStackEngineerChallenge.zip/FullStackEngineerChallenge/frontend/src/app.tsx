import AppContext from "./app-context";
import AppApi from "./apis/app";
import AppStore from "./stores/app";
import { BrowserRouter, Redirect, Route, Switch } from "react-router-dom";
import { observer } from "mobx-react";
import Login from "./pages/login";
import AppRoute from "./components/app-route";
import NotFound from "./pages/not-found";
import Forbidden from "./pages/forbidden";

// pages

import EmployeeList from "./pages/employee/list";
import EmployeeAdd from "./pages/employee/add";
import EmployeeEdit from "./pages/employee/edit";
import EmployeeReviewList from "./pages/employee/review-list";
import ReviewEdit from "./pages/review/edit";
import ReviewAdd from "./pages/review/add";
import ReviewRequestPendingList from "./pages/review-request/pending-list";

const store = new AppStore();
const api = new AppApi(store);

function App() {
  return (
    <AppContext.Provider value={{ store, api }}>
      <BrowserRouter>
        <Switch>
          <AppRoute path="/login" component={Login} />
          <AppRoute
            path="/employee/:id/edit"
            allow={["ADMIN"]}
            component={EmployeeEdit}
          />
          <AppRoute
            path="/employee/:id/review"
            allow={["ADMIN"]}
            component={EmployeeReviewList}
          />
          <AppRoute
            path="/employee/add"
            allow={["ADMIN"]}
            component={EmployeeAdd}
          />
          <AppRoute
            path="/employee"
            allow={["ADMIN"]}
            component={EmployeeList}
          />
          <AppRoute
            path="/review/:id"
            allow={["ADMIN"]}
            component={ReviewEdit}
          />

          <AppRoute
            path="/review/add"
            allow={["EMPLOYEE"]}
            component={ReviewEdit}
          />

          <AppRoute
            path="/review-request/:id"
            allow={["EMPLOYEE", "ADMIN"]}
            component={ReviewAdd}
          />

          <AppRoute
            path="/review-request"
            allow={["EMPLOYEE", "ADMIN"]}
            component={ReviewRequestPendingList}
          />

          {!store.auth.isSignedIn && <Redirect exact path="/" to="/login" />}

          {store.auth.user?.isAdmin && (
            <Redirect exact path="/" to="/employee" />
          )}

          {store.auth.user?.isEmployee && (
            <Redirect exact path="/" to="/review-request" />
          )}

          <Route path="forbidden" component={Forbidden} />
          <Route path="/not-found" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </BrowserRouter>
    </AppContext.Provider>
  );
}

export default observer(App);
