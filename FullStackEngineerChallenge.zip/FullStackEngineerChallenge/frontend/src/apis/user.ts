import AppStore from "../stores/app";
import {
  ApiResponse,
  CreateEmployeeOps,
  UpdateEmployeeOps,
} from "../types/api";
import AppApi from "./app";

export default class UserApi {
  constructor(private api: AppApi, private store: AppStore) {}

  async getAll() {
    const res = await this.api.client.get<ApiResponse>("/user");
    this.store.user.load(res.data.users);
  }

  async get(id: number) {
    const res = await this.api.client.get<ApiResponse>(`/user/${id}`);
    this.store.user.load(res.data.users);
  }

  async createEmployee(employee: CreateEmployeeOps) {
    const res = await this.api.client.post<ApiResponse>("/user", employee);
    this.store.user.load(res.data.users);
  }

  async updateEmployee(employee: UpdateEmployeeOps) {
    const res = await this.api.client.put<ApiResponse>(
      `/user/${employee.id}`,
      employee
    );
    this.store.user.load(res.data.users);
  }

  async delete(id: number) {
    await this.api.client.delete(`/user/${id}`);
    this.store.user.delete(id);
  }
}
