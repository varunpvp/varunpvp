import axios from "axios";
import AppStore from "../stores/app";
import AuthApi from "./auth";
import ReviewApi from "./review";
import ReviewRequestApi from "./review-request";
import UserApi from "./user";

export default class AppApi {
  auth: AuthApi;
  user: UserApi;
  review: ReviewApi;
  reviewRequest: ReviewRequestApi;

  private _client = axios.create({
    baseURL: process.env.REACT_APP_API_BASE_URL,
  });

  constructor(store: AppStore) {
    this.auth = new AuthApi(this, store);
    this.user = new UserApi(this, store);
    this.review = new ReviewApi(this, store);
    this.reviewRequest = new ReviewRequestApi(this, store);

    this._client.interceptors.request.use((config) => {
      if (store.auth.accessToken) {
        config.headers["authorization"] = store.auth.accessToken;
      }
      return config;
    });
  }

  get client() {
    return this._client;
  }
}
