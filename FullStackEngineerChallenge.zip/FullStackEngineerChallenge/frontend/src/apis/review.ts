import AppStore from "../stores/app";
import { ApiResponse, CreateReviewOps, UpdateReviewOps } from "../types/api";
import AppApi from "./app";

export default class ReviewApi {
  constructor(private api: AppApi, private store: AppStore) {}

  async getUserReceivedReview(userId: number) {
    const res = await this.api.client.get<ApiResponse>(
      `/review?revieweeId=${userId}`
    );
    this.store.review.load(res.data.reviews);
  }

  async create(review: CreateReviewOps) {
    const res = await this.api.client.post<ApiResponse>(`/review`, review);
    this.store.review.load(res.data.reviews);
  }

  async update(review: UpdateReviewOps) {
    const res = await this.api.client.put<ApiResponse>(
      `/review/${review.id}`,
      review
    );
    this.store.review.load(res.data.reviews);
  }
}
