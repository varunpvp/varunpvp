import AppStore from "../stores/app";
import { ApiResponse, CreateReviewRequestOps } from "../types/api";
import AppApi from "./app";

export default class ReviewRequestApi {
  constructor(private api: AppApi, private store: AppStore) {}

  async getEmployeePendingRequests(employeeId: number) {
    const res = await this.api.client.get<ApiResponse>(
      `/review-request?userId=${employeeId}`
    );
    this.store.reviewRequest.load(res.data.reviewRequests);
    this.store.user.load(res.data.users);
  }

  async create(request: CreateReviewRequestOps) {
    const res = await this.api.client.post<ApiResponse>(
      `/review-request`,
      request
    );
    this.store.reviewRequest.load(res.data.reviewRequests ?? []);
    return res.data.message;
  }
}
