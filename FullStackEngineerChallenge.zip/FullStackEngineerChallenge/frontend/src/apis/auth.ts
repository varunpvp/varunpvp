import AppStore from "../stores/app";
import AppApi from "./app";

export default class AuthApi {
  constructor(private api: AppApi, private store: AppStore) {}

  async signin(email: string, password: string) {
    try {
      const res = await this.api.client.post("/auth/token", {
        email,
        password,
      });

      this.store.auth.loadToken(res.data.token);
    } catch (error) {
      throw Error("Invalid user/password");
    }
  }
}
