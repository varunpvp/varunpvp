import { action, computed, makeObservable, observable } from "mobx";
import ReviewRequest from "../models/review-request";
import IReviewRequest from "../types/review-request";
import AppStore from "./app";

export default class ReviewRequestStore {
  byId = observable.map<number, ReviewRequest>();

  constructor(private store: AppStore) {
    makeObservable(this);
  }

  @action load(data: IReviewRequest[]) {
    data.forEach((it) =>
      this.byId.set(it.id, new ReviewRequest(this.store, it))
    );
  }

  @action remove(id: number) {
    this.byId.delete(id);
  }

  @computed get all() {
    return Array.from(this.byId.values());
  }

  @action clear() {
    this.byId.clear();
  }
}
