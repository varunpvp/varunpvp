import { action, computed, makeObservable, observable } from "mobx";
import Review from "../models/review";
import IReview from "../types/review";
import AppStore from "./app";

export default class ReviewStore {
  byId = observable.map<number, Review>();

  constructor(private store: AppStore) {
    makeObservable(this);
  }

  @action load(data: IReview[]) {
    data.forEach((it) => this.byId.set(it.id, new Review(this.store, it)));
  }

  @action remove(id: number) {
    this.byId.delete(id);
  }

  @computed get all() {
    return Array.from(this.byId.values());
  }

  @action clear() {
    this.byId.clear();
  }
}
