import AuthStore from "./auth";
import ReviewStore from "./review";
import ReviewRequestStore from "./review-request";
import UserStore from "./user";

export default class AppStore {
  auth: AuthStore;
  user: UserStore;
  review: ReviewStore;
  reviewRequest: ReviewRequestStore;

  constructor() {
    this.auth = new AuthStore(this);
    this.user = new UserStore(this);
    this.review = new ReviewStore(this);
    this.reviewRequest = new ReviewRequestStore(this);
  }

  clear() {
    this.user.clear();
    this.review.clear();
    this.reviewRequest.clear();
  }
}
