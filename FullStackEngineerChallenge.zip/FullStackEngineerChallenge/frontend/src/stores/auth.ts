import { action, computed, makeObservable, observable } from "mobx";
import User from "../models/user";
import jwt from "jwt-simple";
import AppStore from "./app";

export default class AuthStore {
  @observable private _user?: User;
  private _accessToken?: string;

  constructor(private store: AppStore) {
    makeObservable(this);

    const accessToken = localStorage.getItem("access-token");

    if (accessToken) {
      this.loadToken(accessToken);
    }
  }

  @action loadToken(token: string) {
    try {
      const decodedToken = jwt.decode(token, "", true);
      this._user = new User(this.store, decodedToken);
      this._accessToken = token;

      localStorage.setItem("access-token", token);
    } catch (error) {
      console.error("AuthStore.loadToken failed", error);
    }
  }

  @action signOut() {
    this._user = undefined;
    this._accessToken = undefined;
    this.store.clear();
    localStorage.removeItem("access-token");
  }

  @computed get isSignedIn() {
    return !!this._user;
  }

  @computed get user() {
    return this._user;
  }

  get accessToken() {
    return this._accessToken;
  }
}
