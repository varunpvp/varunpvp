export default interface IReviewRequest {
  id: number;
  userId: number;
  revieweeId: number;
  createdAt: string;
  updatedAt: string;
}
