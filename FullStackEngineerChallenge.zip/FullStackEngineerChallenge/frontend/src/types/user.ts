export default interface IUser {
  id: number;
  name: string;
  email: string;
  gender: "MALE" | "FEMALE";
  role: "EMPLOYEE" | "ADMIN";
  password: string;
  createdAt: string;
  updatedAt: string;
}
