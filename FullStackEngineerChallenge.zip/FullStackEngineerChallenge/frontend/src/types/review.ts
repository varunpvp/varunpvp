export default interface IReview {
  id: number;
  userId: number;
  revieweeId: number;
  rating: number;
  text: string;
  createdAt: string;
  updatedAt: string;
}
