import IReview from "./review";
import IReviewRequest from "./review-request";
import IUser from "./user";

export interface ApiResponse {
  users: IUser[];
  reviews: IReview[];
  reviewRequests: IReviewRequest[];
  message: string;
}

type Id = { id: number };

export type CreateEmployeeOps = Pick<
  IUser,
  "name" | "email" | "gender" | "password"
>;

export type UpdateEmployeeOps = Id & CreateEmployeeOps;

export type CreateReviewOps = Pick<
  IReview,
  "rating" | "text" | "revieweeId" | "userId"
>;

export type UpdateReviewOps = Id & CreateReviewOps;

export type CreateReviewRequestOps = Pick<
  IReviewRequest,
  "revieweeId" | "userId"
>;
