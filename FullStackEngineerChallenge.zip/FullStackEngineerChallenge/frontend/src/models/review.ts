import { computed, makeObservable } from "mobx";
import AppStore from "../stores/app";
import IReview from "../types/review";

export default class Review implements IReview {
  id: number;
  userId: number;
  revieweeId: number;
  rating: number;
  text: string;
  createdAt: string;
  updatedAt: string;

  constructor(private store: AppStore, review: IReview) {
    makeObservable(this);

    this.id = review.id;
    this.userId = review.userId;
    this.revieweeId = review.revieweeId;
    this.rating = review.rating;
    this.text = review.text;
    this.createdAt = review.createdAt;
    this.updatedAt = review.updatedAt;
  }

  @computed get user() {
    return this.store.user.byId.get(this.userId);
  }

  @computed get reviewee() {
    return this.store.user.byId.get(this.revieweeId);
  }
}
