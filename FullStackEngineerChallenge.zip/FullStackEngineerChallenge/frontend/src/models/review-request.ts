import { computed, makeObservable } from "mobx";
import AppStore from "../stores/app";
import IReviewRequest from "../types/review-request";

export default class ReviewRequest implements IReviewRequest {
  id: number;
  userId: number;
  revieweeId: number;
  createdAt: string;
  updatedAt: string;

  constructor(private store: AppStore, reviewRequest: IReviewRequest) {
    makeObservable(this);

    this.id = reviewRequest.id;
    this.userId = reviewRequest.userId;
    this.revieweeId = reviewRequest.revieweeId;
    this.createdAt = reviewRequest.createdAt;
    this.updatedAt = reviewRequest.updatedAt;
  }

  @computed get user() {
    return this.store.user.byId.get(this.userId);
  }

  @computed get reviewee() {
    return this.store.user.byId.get(this.revieweeId);
  }
}
