import { computed, makeObservable } from "mobx";
import AppStore from "../stores/app";
import IUser from "../types/user";

export default class User implements IUser {
  id: number;
  name: string;
  email: string;
  gender: "MALE" | "FEMALE";
  role: "EMPLOYEE" | "ADMIN";
  password: string;
  createdAt: string;
  updatedAt: string;

  constructor(private store: AppStore, user: IUser) {
    makeObservable(this);

    this.id = user.id;
    this.name = user.name;
    this.email = user.email;
    this.gender = user.gender;
    this.role = user.role;
    this.password = user.password;
    this.createdAt = user.createdAt;
    this.updatedAt = user.updatedAt;
  }

  @computed get isAdmin() {
    return this.role === "ADMIN";
  }

  @computed get isEmployee() {
    return this.role === "EMPLOYEE";
  }

  @computed get submittedReviews() {
    return this.store.review.all.filter((it) => it.userId === this.id);
  }

  @computed get receivedReviews() {
    return this.store.review.all.filter((it) => it.revieweeId === this.id);
  }

  @computed get pendingReviewRequests() {
    return this.store.reviewRequest.all.filter((it) => it.userId === this.id);
  }

  @computed get awaitedReviewRequests() {
    return this.store.reviewRequest.all.filter(
      (it) => it.revieweeId === this.id
    );
  }

  @computed get nameWithEmail() {
    return `${this.name} (${this.email})`;
  }
}
