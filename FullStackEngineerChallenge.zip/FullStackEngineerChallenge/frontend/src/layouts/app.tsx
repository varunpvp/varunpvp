import Sider from "antd/lib/layout/Sider";
import Menu from "antd/lib/menu";
import UserOutlined from "@ant-design/icons/UserOutlined";
import Layout, { Content, Header } from "antd/lib/layout/layout";
import { useAppContext } from "../app-context";
import { observer } from "mobx-react";
import { useHistory } from "react-router";
import Logo from "../components/logo";
import React, { Fragment } from "react";
import { Avatar } from "antd";
import SubMenu from "antd/lib/menu/SubMenu";
import UnorderedListOutlined from "@ant-design/icons/UnorderedListOutlined";

const AppLayout: React.FC = ({ children }) => {
  const context = useAppContext();
  const history = useHistory();
  const auth = context.store.auth;

  const menu = [
    {
      key: "employee",
      title: "Employees",
      icon: <UserOutlined />,
      visible: auth.user?.isAdmin,
    },
    {
      key: "review-request",
      title: "Review Requests",
      icon: <UnorderedListOutlined />,
      visible: auth.user?.isEmployee || auth.user?.isAdmin,
    },
  ].filter((it) => it.visible);

  if (!auth.isSignedIn) {
    return (
      <Layout style={{ padding: "0 24px 24px" }}>
        <Content
          style={{
            margin: 0,
            minHeight: 280,
          }}
        >
          {children}
        </Content>
      </Layout>
    );
  }

  return (
    <Layout className="min-h-screen">
      <Header
        className="flex justify-between items-center px-0"
        style={{ paddingLeft: 0, paddingRight: 0 }}
      >
        <Logo darkTheme />
        <Menu
          key="user"
          mode="horizontal"
          onClick={(option) => {
            if (option.key === "SignOut") {
              auth.signOut();
            }
          }}
          theme="dark"
          selectable={false}
        >
          <SubMenu
            title={
              <Fragment>
                <span style={{ color: "#999", marginRight: 4 }}>Hi,</span>
                <span>{auth.user?.name}</span>
                <Avatar style={{ marginLeft: 8 }}>
                  {auth.user?.name.charAt(0)}
                </Avatar>
              </Fragment>
            }
          >
            <Menu.Item key="SignOut">Sign out</Menu.Item>
          </SubMenu>
        </Menu>
      </Header>
      <Layout>
        <Sider width={200}>
          <Menu
            theme="dark"
            mode="inline"
            onClick={(option) => history.push(("/" + option.key) as string)}
          >
            {menu.map((it) => (
              <Menu.Item icon={it.icon} key={it.key}>
                {it.title}
              </Menu.Item>
            ))}
          </Menu>
        </Sider>
        <Layout style={{ padding: "0 24px 24px" }}>
          <Content
            style={{
              margin: 0,
              minHeight: 280,
            }}
          >
            {children}
          </Content>
        </Layout>
      </Layout>
    </Layout>
  );
};

export default observer(AppLayout);
