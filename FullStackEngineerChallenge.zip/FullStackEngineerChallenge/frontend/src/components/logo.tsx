const Logo: React.FC<{ darkTheme?: boolean }> = ({ darkTheme = false }) => {
  return (
    <div
      style={{
        display: "block",
        margin: 12,
        color: darkTheme ? "white" : "black",
        padding: 4,
        textAlign: "center",
      }}
    >
      Employee Review System
    </div>
  );
};

export default Logo;
