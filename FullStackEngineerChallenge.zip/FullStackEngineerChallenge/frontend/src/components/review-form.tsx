import { Rate } from "antd";
import Button from "antd/lib/button";
import Form from "antd/lib/form";
import Input from "antd/lib/input";
import React, { useState } from "react";

type Values = { rating: number; text: string };

interface Props {
  values?: Values;
  onFinish: (values: Values) => Promise<void>;
}

const ReviewForm: React.FC<Props> = ({ values, onFinish }) => {
  const [loading, setLoading] = useState(false);
  return (
    <Form<Values>
      layout="vertical"
      onFinish={async (values) => {
        try {
          setLoading(true);
          await onFinish(values);
        } finally {
          setLoading(false);
        }
      }}
      initialValues={values}
    >
      <Form.Item
        name="rating"
        label="Rating"
        rules={[{ required: true }]}
        hasFeedback
      >
        <Rate />
      </Form.Item>
      <Form.Item name="text" label="Comment">
        <Input.TextArea />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit" block loading={loading}>
          Save
        </Button>
      </Form.Item>
    </Form>
  );
};

export default ReviewForm;
