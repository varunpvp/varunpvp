import Button from "antd/lib/button";
import Form from "antd/lib/form";
import Input from "antd/lib/input";
import Select from "antd/lib/select";
import React, { useState } from "react";
import { CreateEmployeeOps } from "../types/api";

interface Props {
  values?: CreateEmployeeOps;
  onFinish: (values: CreateEmployeeOps) => Promise<void>;
  editing?: boolean;
}

const EmployeeForm: React.FC<Props> = ({
  values,
  onFinish,
  editing = false,
}) => {
  const [loading, setLoading] = useState(false);
  return (
    <Form<CreateEmployeeOps>
      layout="vertical"
      onFinish={async (values) => {
        try {
          setLoading(true);
          await onFinish(values);
        } finally {
          setLoading(false);
        }
      }}
      initialValues={values}
    >
      <Form.Item
        name="name"
        label="Name"
        rules={[{ required: true }]}
        hasFeedback
      >
        <Input placeholder="Name" />
      </Form.Item>
      <Form.Item name="gender" label="Gender" initialValue="MALE">
        <Select>
          <Select.Option value="MALE">Male</Select.Option>
          <Select.Option value="FEMALE">Female</Select.Option>
        </Select>
      </Form.Item>
      <Form.Item
        name="email"
        label="Email"
        rules={[{ required: true }]}
        hasFeedback
      >
        <Input placeholder="Email" />
      </Form.Item>
      <Form.Item
        name="password"
        label="Password"
        rules={[{ required: !editing }]}
        hasFeedback
      >
        <Input placeholder="Password" />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit" block loading={loading}>
          Save
        </Button>
      </Form.Item>
    </Form>
  );
};

export default EmployeeForm;
