import { AutoComplete, message } from "antd";
import Avatar from "antd/lib/avatar/avatar";
import List from "antd/lib/list";
import Modal from "antd/lib/modal/Modal";
import { observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import { useAppContext } from "../app-context";

interface Props {
  reviewRequestUserId?: number;
  onClose?: () => void;
}

const ReviewRequestModal: React.FC<Props> = ({
  reviewRequestUserId,
  onClose,
}) => {
  const context = useAppContext();
  const [searchText, setSearchText] = useState("");
  const [loading, setLoading] = useState(false);

  const user = reviewRequestUserId
    ? context.store.user.byId.get(reviewRequestUserId)
    : null;
  const employees = context.store.user.all.filter(
    (it) => it.id !== reviewRequestUserId
  );

  const loadPendingReviewRequests = async () => {
    if (reviewRequestUserId) {
      try {
        setLoading(true);
        await context.api.reviewRequest.getEmployeePendingRequests(
          reviewRequestUserId
        );
      } finally {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    loadPendingReviewRequests();
  }, [reviewRequestUserId]);

  return (
    <Modal
      title={`Send review request to ${user?.name}`}
      visible={!!reviewRequestUserId}
      okButtonProps={{ hidden: true }}
      cancelButtonProps={{ type: "primary" }}
      confirmLoading={loading}
      onCancel={() => onClose?.()}
      cancelText="Close"
      destroyOnClose
    >
      <AutoComplete
        value={searchText}
        onChange={(value) => setSearchText(value)}
        placeholder="Search employee to request reivew..."
        className="w-full mb-4"
        filterOption
        onSelect={async (value) => {
          try {
            setSearchText("");
            setLoading(true);
            const response = await context.api.reviewRequest.create({
              userId: reviewRequestUserId!,
              revieweeId: Number(value),
            });

            message.success(response);
          } catch {
            message.error("Something went wrong!");
          } finally {
            setLoading(false);
          }
        }}
        options={employees.map((it) => ({
          label: it.nameWithEmail,
          value: `${it.id}`,
          filterBy: it.name,
        }))}
        optionFilterProp="filterBy"
      />
      <List
        header="Pending review requests"
        loading={loading}
        dataSource={user?.pendingReviewRequests}
        renderItem={(it) => (
          <List.Item>
            <List.Item.Meta
              avatar={<Avatar>{it.reviewee?.name.charAt(0)}</Avatar>}
              title={it.reviewee?.name}
              description={it.reviewee?.email}
            />
          </List.Item>
        )}
      />
    </Modal>
  );
};

export default observer(ReviewRequestModal);
