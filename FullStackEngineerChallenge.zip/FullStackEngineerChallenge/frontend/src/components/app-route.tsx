import { observer } from "mobx-react";
import { Redirect, Route } from "react-router";
import { useAppContext } from "../app-context";
import AppLayout from "../layouts/app";
import IUser from "../types/user";

interface Props {
  path: string;
  component: React.ComponentType;
  allow?: IUser["role"][];
}

const AppRoute: React.FC<Props> = ({ allow, component: Component, path }) => {
  const context = useAppContext();
  const auth = context.store.auth;

  if (!allow && auth.isSignedIn) {
    return <Redirect to="/" />;
  }

  if (allow && !auth.isSignedIn) {
    return <Redirect to="/login" />;
  }

  if (allow && auth.isSignedIn && !allow.includes(auth.user!.role)) {
    return <Redirect to="/forbidden" />;
  }

  return (
    <Route
      path={path}
      render={() => (
        <AppLayout>
          <Component />
        </AppLayout>
      )}
    />
  );
};

export default observer(AppRoute);
