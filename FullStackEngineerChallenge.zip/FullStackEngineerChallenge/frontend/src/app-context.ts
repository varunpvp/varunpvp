import React from "react";
import AppApi from "./apis/app";
import AppStore from "./stores/app";

export type AppContextType = {
  api: AppApi;
  store: AppStore;
};

const AppContext = React.createContext<AppContextType | null>(null);

export const useAppContext = () =>
  React.useContext(AppContext) as AppContextType;

export default AppContext;
